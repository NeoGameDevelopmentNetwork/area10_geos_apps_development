# Area6510

### Input-de-Luxe
This is a small utility to add better input methods to BASIC applications.
See releases section for details.
