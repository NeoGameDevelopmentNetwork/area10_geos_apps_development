# Area6510

### hdPartInit
This program can be used to automatically create partitions on a CMD-HD.

You can create a custom partition list or import the partition list from another device. This can be used to create the same partitions on a backup device as on the original device.
After the partitions were created you can use cbmSCSIcopy64 or geoSCSIcopy64 to copy partitions from the source device to the target device.

#### Modules
This directory includes the BASIC code for cbmHDscsi64 splitted into several smaller modules with additional comments.
