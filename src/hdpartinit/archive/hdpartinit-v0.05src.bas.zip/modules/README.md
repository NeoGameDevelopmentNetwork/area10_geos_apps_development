# Area6510

### hdPartInit / Modules
These files are for documentation purposes only.

The code listed here is the original "source" code with additional comments.
The source files are merged using a small linux/bash-script and then converted to a real BASIC programm using petcat.
