# Area6510

### copydisk
The goal of this project is to be able to copy disk or disk images between drives and SD2IEC/VICE/CMDNative directories.
C=1541, C=1571, C=1581 and CMD Native supported.
