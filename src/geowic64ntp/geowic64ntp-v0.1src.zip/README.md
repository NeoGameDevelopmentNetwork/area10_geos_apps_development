# Area6510

### geoWiC64ntp
The goal of this project is set the GEOS system date and time using the WiC64 and a NTP server. Requires a Commodore64 with WiC64 running GEOS/MegaPatch64 or GDOS64.
