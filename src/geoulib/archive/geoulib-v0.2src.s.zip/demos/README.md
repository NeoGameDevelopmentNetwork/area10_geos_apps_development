# AREA6510

### geoULib demo applications
This directory includes the source code documentation for some demo applications that will demonstrate how to use the geoULib code in own applications.
These demos are not designed to be complete applications since they do not have a comfortable user interface. Instead you have to edit the GEOS infoblock and add a path to a directory or a file to test these demos. Using a full path (like /Usb0/testdir/test.d64) is recommende.
