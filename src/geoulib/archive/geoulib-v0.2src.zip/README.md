# AREA6510

### geoULib
geoULib is a collection of assembler routines to communicate with Ultimate devices (U64, UII+) under GEOS via the Ultimate Control Interface (UCI).
The routines are developed for use with the GEOS-MegaAssembler, but should be convertible for other assemblers as well.

Released: 2023/05/20 20:00
Version : V0.2
