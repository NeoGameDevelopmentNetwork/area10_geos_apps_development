# Area6510

### geoWLoad64
The goal of this project is to download files with the WiC64 over the internet directly to the Commodore64 running GEOS/MegaPatch64 or GDOS64.
