# Area6510

### cbmSCSIcopy64
The goal of this project is to be able to copy partitions between different SCSI devices connected to a CMD-HD.

#### Modules
This directory includes the BASIC code for cbmSCSIcopy64 splitted into several smaller modules with additional comments.
