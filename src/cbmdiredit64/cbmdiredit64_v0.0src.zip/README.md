# Area6510

### cbmDirEdit64
The goal of this project is to enable users to edit the date and time of files on floppy disks or disk images. Supported are 1541, 1571, 1581 and NativeMode. It is also possible to edit file name, file type and file size.
