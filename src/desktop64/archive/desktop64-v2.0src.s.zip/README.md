# Area6510

### DESKTOP V2
This is the documentation for the reassembled source code for the GEOS DESKTOP V2.x

The developer source code currently compiles an exact 1:1 copy of "DESK TOP" using GEOS/MegaAssembler.
