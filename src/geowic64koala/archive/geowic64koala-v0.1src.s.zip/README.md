# Area6510

### geoWiC64Koala
GEOS version of the WiC64 koala demo. Requires a Commodore64 with WiC64 running GEOS/MegaPatch64 or GDOS64.
