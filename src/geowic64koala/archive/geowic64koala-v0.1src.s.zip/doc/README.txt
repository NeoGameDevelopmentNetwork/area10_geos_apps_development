﻿; UTF-8 Byte Order Mark (BOM), do not remove!
;
; Area6510 (c) by Markus Kanet
;
; This file is used to document the source code, not for
; creating an executable program.
;

geoWiC64koala
GEOS version of the WiC64 Koala demo.

Version 0.1
Released: 2022/04/18

This application will load the KOALA images from the WiC64.de server just like the Koala demo.
The keyboard is checked during the GEOS main loop, maybe you have to hold down the keys longer if necessary.
RETURN    Exit application
F7        Pause slide show
0-9       Set slide show speed
SHIFT 0-4 Jump to image 000/100/200/300/400

ChangeLog:
2022/04/18 - V0.1
- Initial release.
