# Area6510

# GEOS MEGAPATCH 64/128 [GERMAN]
For english translation please scroll down...


### PATCH#01
Dieses Verzeichnis beinhaltet einige aktualisierte Dateien:

##### Disk#3 mp3_system:
* D5-EDIT1.CVT  => s.MP3.Edit.1
* D5-EDIT2.CVT  => - G3_Editor.Init
Die Init-Routine des GEOS.Editors wurde in eine eigene Datei ausgelagert und mit einer Status-Anzeige versehen.

##### Disk#5 mp3_program:
* D5-GMP2.CVT   => s.GEOS128.MP3
Fehlerbeseitigung 40Z-Setup. Bei fehlenden RBOOT-Dateien kann die Installation fortgesetzt werden.
* D5-GMP1.CVT   => s.GEOS64.MP3
Anpassung an die MP128-Version.

Die aktualisierten Dateien liegen im GeoConvert-Format vor. Nach der konvertierung einfach die entsprechenden Dateien auf den D81-images der Version rev.2 austauschen.

2018/06/27
M.Kanet




# GEOS MEGAPATCH 64/128 [ENGLISH]

### PATCH#01
This directory contains some updated files:

##### Disk#3 mp3_system:
* D5-EDIT1.CVT => s.MP3.Edit.1
* D5-EDIT2.CVT => - G3_Editor.Init
The Init-Routine of the GEOS.Editor has been swapped out to a separate file and now includes a status information bar.

##### Disk#5 mp3_program:
* D5-GMP2.CVT => s.GEOS128.MP3
Troubleshooting 40Z setup. When RBOOT-files are missing continue with the setup.
* D5-GMP1.CVT => s.GEOS64.MP3
Adaptation to the MP128 version.

The updated files are in GeoConvert format. After the conversion simply replace the corresponding files on the D81-images of version rev.2.

2018/06/27
M.Kanet
