# Area6510

### GEODESK64
Some very early source code of GEODESK.
