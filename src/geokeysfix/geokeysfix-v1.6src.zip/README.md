# Area6510

### geoKeysFix
This is a small utility to fix a problem with geoKeys when using GEOS/MegaPatch 64/128.
