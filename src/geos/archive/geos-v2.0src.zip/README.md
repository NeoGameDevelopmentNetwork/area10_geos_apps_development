# Area6510

### GEOS 2.0
This directory includes the GEOS 2/german source code documentation and also some code for additional applications like configure.
This was the code base used for GEOS MegaPatch3.
