# Area6510

## GEOS MEGAPATCH 64 V3.3r6 - Update.01

#### Changes
The FD71/HD71/RL71 disk drivers do not set the ":doubleSideFlg" correctly. Applications which evaluate the flag may only copy the "first side" of a corresponding partition.
