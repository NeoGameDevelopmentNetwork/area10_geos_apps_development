# Area6510

## GEOS MEGAPATCH 64/128
This directory contains current releases of GEOS MegaPatch.
English / MP64 disk #1 : 'mp33r3aes1.d64'
English / MP64 disk #2 : 'mp33r3aes2.d64'
English / MP128 disk #1 : 'mp33r3bes1.d64'
English / MP128 disk #2 : 'mp33r3bes2.d64'
