# Area6510

## GEOS MEGAPATCH 64 V3.3r5 - Update.01

#### Changes
This D64 includes an update driver for GEOS MegaPatch64 V3.3r5 to fix a bug with the TurboChameleon64:
When using the original mouse driver the pointer may move itself automatically.

For users wothout a TurboChameleon64 this update will not change anything.
