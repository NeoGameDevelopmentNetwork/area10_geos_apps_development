# Area6510

## GEOS MEGAPATCH 64/128
This directory contains current releases of GEOS MegaPatch.
German / MP64 disk #1 : 'mp33r2ads1.d64'
German / MP64 disk #2 : 'mp33r2ads2.d64'
German / MP128 disk #1 : 'mp33r2bds1.d64'
German / MP128 disk #2 : 'mp33r2bds2.d64'
