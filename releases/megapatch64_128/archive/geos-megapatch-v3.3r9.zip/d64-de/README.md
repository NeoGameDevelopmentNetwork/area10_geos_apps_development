# Area6510

## GEOS MEGAPATCH 64/128
This directory contains current releases of GEOS MegaPatch.
German / MP64 disk #1 : 'mp33r9ads1.d64'
German / MP64 disk #2 : 'mp33r9ads2.d64'
German / MP128 disk #1 : 'mp33r9bds1.d64'
German / MP128 disk #2 : 'mp33r9bds2.d64'
German / MP128 : 'mp33r9bd.d71'
