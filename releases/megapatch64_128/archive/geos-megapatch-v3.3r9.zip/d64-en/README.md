# Area6510

## GEOS MEGAPATCH 64/128
This directory contains current releases of GEOS MegaPatch.
English / MP64 disk #1 : 'mp33r9aes1.d64'
English / MP64 disk #2 : 'mp33r9aes2.d64'
English / MP128 disk #1 : 'mp33r9bes1.d64'
English / MP128 disk #2 : 'mp33r9bes2.d64'
English / MP128 : 'mp33r9be.d71'
