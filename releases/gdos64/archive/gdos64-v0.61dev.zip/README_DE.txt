
Willkommen zum GEOS-Update `GDOS64`
by Markus Kanet

WARNUNG:
SYSTEM IST IN DER ENTWICKLUNG!
ENTHALTENE FEHLER KÖNNEN ZU DATENVERLUST FÜHREN!
NUTZUNG AUF EIGENES RISIKO!

Systemanforderungen:
Commodore 64
512Kb RAM (C=REU, GeoRAM, RAMCard, RAMLink)
Commodore 1351 oder kompatible Maus

Empfohlen:
1024Kb RAM
CMD-SuperCPU oder TurboChameleon64

Hinweis: Das Ultimate64 mit Turbo-Firmware
wird offiziell nicht unterstützt!

Installation:
Die Datei "SETUPGD64DE" auf ein RAM-Laufwerk kopieren und von dort
starten, da die Analyse der Setup-Daten auf physikalischen Laufwerken
sehr lange dauern kann.

Tipps:
* Installation auf eine leere Diskette:
  Das System benötigt ca. 460Kb Speicher auf dem Ziel-Laufwerk.
* Kein MakeBoot mehr erforderlich:
  Startdiskette sollte auf allen unterstützen Laufwerken funktionieren.
* "Treiber-in-RAM" aktivieren:
  Für den Wechsel des Modus auf SD2IEC+CMDRL/FD/HD-Laufwerken.
* Treiber von Disk starten:
  GD.DISK.xxx Dateien können von GeoDesk direkt gestartet werden.
  Ablegen auf dem DeskTop als AppLink ist möglich.

Hinweise:
* Auf zwei verschiedenen Systemen gestestet:
  Fehler können aber nicht ausgeschlossen werden.
* Hilfefunktion noch unvollständig:
  Die vorhandenen Dateien diesen als Demo-Beispiel.
* GDOS64 am C64 von einem C=1571-Laufwerk starten:
  Das C=1571-Laufwerk in den doppelseitigen Modus umschalten!
  OPEN 15,x,15,"U0>M1":CLOSE 15     :REM x = Geräteadresse

Geschichte:
1997: GEOS reassembliert
1999: GEOS MegaPatch veröffentlicht
1999: Start am Nachfolger GeoDOS64-V3
2021: Übernahme Änderungen von MegaPatch in GeoDOS64-V3
2022: GeoDOS64 V3 in GDOS64 umbenannt

Stand: 19.01.2023
